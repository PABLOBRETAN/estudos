import HomePageComponent from '../src/components/HomePage/HomePage'

export default function HomePage() {
  return <HomePageComponent />
}