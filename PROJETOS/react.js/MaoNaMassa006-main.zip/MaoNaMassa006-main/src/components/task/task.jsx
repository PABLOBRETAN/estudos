import styles from './task.module.css'

function Task () {

  return (
    <div className={styles.task}>
      Task
    </div>
  )
}

export default Task